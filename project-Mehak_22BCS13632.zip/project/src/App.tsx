import React from 'react';
import { Users, BookOpen, Calendar, MessageCircle, Heart } from 'lucide-react';

function App() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50">
      {/* Hero Section */}
      <header className="bg-white shadow-sm">
        <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-2">
              <Heart className="h-6 w-6 text-purple-600" />
              <span className="text-xl font-semibold text-gray-900">FamilyConnect</span>
            </div>
            <div className="hidden md:flex space-x-8">
              <a href="#resources" className="text-gray-600 hover:text-purple-600">Resources</a>
              <a href="#support" className="text-gray-600 hover:text-purple-600">Support Groups</a>
              <a href="#events" className="text-gray-600 hover:text-purple-600">Events</a>
              <button className="bg-purple-600 text-white px-4 py-2 rounded-md hover:bg-purple-700">
                Join Network
              </button>
            </div>
          </div>
        </nav>
      </header>

      <main>
        {/* Hero Section */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <div className="text-center">
            <h1 className="text-4xl font-bold text-gray-900 sm:text-5xl md:text-6xl">
              Supporting Families,
              <span className="text-purple-600"> Building Communities</span>
            </h1>
            <p className="mt-3 max-w-md mx-auto text-base text-gray-500 sm:text-lg md:mt-5 md:text-xl md:max-w-3xl">
              Connect with resources, support groups, and services for families with disabled members.
              Join our caring community today.
            </p>
            <div className="mt-5 max-w-md mx-auto sm:flex sm:justify-center md:mt-8">
              <div className="rounded-md shadow">
                <a href="#get-started" className="w-full flex items-center justify-center px-8 py-3 border border-transparent text-base font-medium rounded-md text-white bg-purple-600 hover:bg-purple-700 md:py-4 md:text-lg md:px-10">
                  Get Started
                </a>
              </div>
            </div>
          </div>
        </div>

        {/* Features Section */}
        <div className="bg-white py-16">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-4">
              <FeatureCard
                icon={<Users className="h-8 w-8 text-purple-600" />}
                title="Support Groups"
                description="Connect with other families who understand your journey"
              />
              <FeatureCard
                icon={<BookOpen className="h-8 w-8 text-purple-600" />}
                title="Resources"
                description="Access educational materials and helpful guides"
              />
              <FeatureCard
                icon={<Calendar className="h-8 w-8 text-purple-600" />}
                title="Events"
                description="Join local meetups and community activities"
              />
              <FeatureCard
                icon={<MessageCircle className="h-8 w-8 text-purple-600" />}
                title="Community"
                description="Share experiences and advice with other families"
              />
            </div>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-gray-50">
        <div className="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <Heart className="h-6 w-6 text-purple-600 mx-auto" />
            <p className="mt-4 text-gray-500">© 2024 FamilyConnect. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

function FeatureCard({ icon, title, description }) {
  return (
    <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-100 hover:shadow-md transition-shadow">
      <div className="flex flex-col items-center text-center">
        <div className="flex items-center justify-center h-12 w-12 rounded-md bg-purple-100 mb-4">
          {icon}
        </div>
        <h3 className="text-lg font-medium text-gray-900 mb-2">{title}</h3>
        <p className="text-gray-500">{description}</p>
      </div>
    </div>
  );
}

export default App;